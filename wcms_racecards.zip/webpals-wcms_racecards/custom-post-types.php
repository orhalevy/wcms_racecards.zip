<?php

require_once 'services/pa-service.php';

function horse_race_card_post_type() {
    register_post_type( 'horse-race-card',
        array(
            'labels' => array(
                'name' => __( 'Horse Race Cards' ),
                'singular_name' => __( 'Horse Race Card' ),
                'add_new' => __( 'Add New Horse Race Card' ),
                'add_new_item' => __( 'Add New Horse Race Card' ),
                'edit_item' => __( 'Edit Horse Race Card' ),
                'new_item' => __( 'Add New Horse Race Card' ),
                'view_item' => __( 'View Horse Race Card' ),
                'search_items' => __( 'Search Horse Race Card' ),
                'not_found' => __( 'No Race Cards found' ),
                'not_found_in_trash' => __( 'No Horse Race Cards found in trash' )
            ),
            'public' => true,
            'supports' => array( 'title', 'editor', 'thumbnail', 'comments', 'sidebar' ),
            'capability_type' => 'post',
            'rewrite' => array("slug" => "horse_race"), // Permalinks format
            'show_in_menu' => false,
            'register_meta_box_cb' => 'add_horse_race_card_meta_boxes'
        )
    );

    $args = array(
        'name'          => 'Horse Race Cards',
        'id'            => sanitize_title('Horse Race Cards'),
        'description'   => '',
        'class'         => '',
        'before_widget' => '',
        'after_widget'  => '',
        'before_title'  => '',
        'after_title'   => '' );
    register_sidebar($args);
}

/* Add the racecard post type */
add_action( 'init', 'horse_race_card_post_type' );

function wpt_horse_race_card(){
    global $post;

    echo '<input type="hidden" name="racecards_race_meta_noncename" id="racecards_race_meta_noncename" value="' .
        wp_create_nonce( plugin_basename(__FILE__) ) . '" />';

    $horse_race_id = get_post_meta($post->ID, 'horse_race_id', true);
    $races_full = WCMSRacecardsUtils::get_all_non_expired_races()->data;
    echo "<select name='horse_race_id'>";
    echo '<option value="select_race">Select Race</option>';
    foreach ($races_full as $race){
        echo '<option value="' . $race->raceId . '" ';
        echo($race->raceId == $horse_race_id ? 'selected' : '');
        echo '>'.$race->course.' '.$race->date.' '.$race->time.'</option>';
    }
    echo "</select>";
}


function update_post_meta_with_selected_race_and_corresponding_permalink($post_id){

    // verify this came from the our screen and with proper authorization,
    // because save_post can be triggered at other times
    if ( !wp_verify_nonce( $_POST['racecards_race_meta_noncename'], plugin_basename(__FILE__) )) {
        return $post_id;
    }

    $racecards_url_handler = new racecards_url_handler();
    update_post_meta($post_id, 'horse_race_id', $_POST['horse_race_id']);
    $racecards_url_handler->build_slug_for_post($post_id);
}

/* Add the racecard post type */
add_action( 'save_post', 'update_post_meta_with_selected_race_and_corresponding_permalink' );


function add_horse_race_card_meta_boxes(){
    add_meta_box("select_race", "Select Race", "wpt_horse_race_card", 'horse-race-card', "side", "default");
    add_meta_box("sidebar_meta", "Sidebar Selection", "sidebar_link", 'horse-race-card', "side", "default");
}