<?php

require_once plugin_dir_path(__DIR__) . 'vendor/autoload.php';
if(!class_exists('GuzzleHttp\Client')){
    require_once plugin_dir_path(__DIR__) . 'vendor/guzzlehttp/guzzle/src/Client.php';
}
use GuzzleHttp\Client;

//TODO after local env DB is set up
/**
 * @return string set env url
 */
//function racecards_env_url() {
//    $getEnvs = get_option('racecards_service_option_name[env]');
//
//    if ($getEnvs == 'production') {
//        $Envs = 'http://oddspros.com/wp-content/plugins/racecards_service/ajax_handler.php';
//    } else{
//        $Envs = 'http://odds.web/wp-content/plugins/racecards_service/ajax_handler.php';
//    }
//    return $Envs;
//}

/**
 * @param $params
 * @return bool|mixed
 */
function send_request_to_racecards_service($params) {
    if(!empty($params)){
        $env = 'http://oddspros.com/wp-content/plugins/racecards_service/ajax_handler.php';
//        $env = racecards_env_url();
        $client = new Client();
        $ch = curl_init($env);
        curl_setopt($ch, CURLOPT_TIMEOUT, 5);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $data = curl_exec($ch);

        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if($httpcode>=200 && $httpcode<300){
            $res = $client->request('GET',$env.'?'. http_build_query($params));
            $json = json_decode($res->getBody());
            return $json;
        }else {
            return false;
        }
    }
}
