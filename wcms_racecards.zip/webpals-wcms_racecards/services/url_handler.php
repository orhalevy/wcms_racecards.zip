<?php
/**
 * Created by PhpStorm.
 * User: eliran.a
 * Date: 7/10/2018
 * Time: 3:05 PM
 */

class racecards_url_handler {

    private $racecards_page_types;
    private $racecards_post_types;
    private $all_racecards_posts_and_pages_ids;
    private $default_slug;
    private $default_results_slug;
    private $default_tomorrow_slug;
    private $slug_db_meta_key;
    private $base_slug;

    function __construct(){
        //get settings from plugin's settings page into as object
        $plugin_settings = get_racecards_settings();

        $this->base_slug = $plugin_settings['base_slug'];
        $config = json_decode(file_get_contents(RACECARDS_PLUGIN_PATH . 'conf/config.json'), true);
        date_default_timezone_set($config['locale']);
        define('FILE_EXTENSION', '.php');

        $this->default_slug = strtolower('racecards');
        $this->default_results_slug = strtolower('results');
        $this->default_tomorrow_slug = strtolower('tomorrow');

        $this->racecards_page_types = $config['page_types'];
        $this->slug_db_meta_key = $config['slug_db_meta_key'];
        $this->racecards_post_types = $config['post_types'];
        $this->update_all_racecards_posts_and_pages_ids();
    }

    private function update_all_racecards_posts_and_pages_ids(){
        $result_array = array();

        foreach($this->racecards_post_types as $post_type){
            $posts_of_this_post_type = get_posts(array('post_type'=>$post_type));
            foreach ($posts_of_this_post_type as $post){
                array_push($result_array, $post->ID);
            }
        }
        foreach($this->racecards_page_types as $page_type){
            $pages_of_this_page_type = get_pages(array('meta_key'=>'_wp_page_template', 'meta_value'=>$page_type.FILE_EXTENSION));
            foreach ($pages_of_this_page_type as $page){
                array_push($result_array, $page->ID);
            }
        }

        $this->all_racecards_posts_and_pages_ids = $result_array;
    }

    private function build_according_to_page_post_type($post_id){
        if(!empty($page_type = get_post_meta($post_id, '_wp_page_template', true))){//page
            switch ($page_type){
                case "today-page".FILE_EXTENSION:
                    $slug_tail = "".$this->default_slug;
                    break;
                case "tomorrow-page".FILE_EXTENSION:
                    $slug_tail = $this->default_slug."/".$this->default_tomorrow_slug;
                    break;
                case "results-race".FILE_EXTENSION:
                    $slug_tail = $this->default_results_slug."/".'race';
                    break;
                case "results-general".FILE_EXTENSION:
                    $slug_tail = $this->default_results_slug;
                    break;
                default:
                    $slug_tail = "";
            }
        }else{//post, meaning there's a selected race in the db
            $post_type = get_post_type($post_id);
            $horse_race_id = get_post_meta($post_id, 'horse_race_id', true);
            $horse_race = WCMSRacecardsUtils::get_race_by_id($horse_race_id)->data[0];
            switch ($post_type){
                case "horse-race-card":
                    $slug_tail = $this->default_slug."/".$this->swap_date_format($horse_race->date)."/".$this->replace_spaces_with_underscores(strtolower($horse_race->course))."-".$this->compact_time_string($horse_race->time);
                    break;
                default:
                    $slug_tail = "";
            }
        }

        return $slug_tail;
    }

    private function swap_date_format($date) {
        return implode("-", array_reverse(explode("-", $date)));
    }

    private function replace_spaces_with_underscores($string){
        return str_replace(' ','_',$string);
    }

    private function replace_underscores_with_spaces($string){
        return str_replace('_',' ',$string);
    }

    private function is_there_a_post_for_this_race($race_id) {
        foreach ($this->all_racecards_posts_and_pages_ids as $post_id){
            if($race_id == get_post_meta($post_id, 'horse_race_id', true)){
                return true;
            }
        }
        return false;
    }

    private function compact_time_string($time) {
        $time_array = explode(":", $time);
        array_pop($time_array);
        $time_without_seconds = implode($time_array);
        return $time_without_seconds;
    }

    private function is_relevant_path($slug) {
        $exploded_slug = explode("/", $slug);
        if(isset($this->base_slug) && trim($this->base_slug) !== '' && $exploded_slug[0] !== $this->base_slug) {
            return false;
        }
        $default_slug_index = $this->get_default_slug_index($exploded_slug);
        $correct_date_format = $this->is_correct_date($exploded_slug[$default_slug_index + 1]);
        //make sure that the slug is in a proper format for parsing
        return ($correct_date_format && ($this->is_relevant_race_card_path($exploded_slug, $default_slug_index) || $this->is_relevant_race_results_path($exploded_slug) || $this->is_relevant_general_results_path($exploded_slug)));
    }

    private function is_relevant_race_card_path($exploded_slug, $default_slug_index) {
        //make sure that the slug is in a proper format for parsing
        return (sizeof($exploded_slug) >= 3 && in_array($this->default_slug, $exploded_slug) && preg_match('/[_a-z]+[-]\d{4}$/', $exploded_slug[$default_slug_index + 2]) == 1);
    }

    private function is_relevant_race_results_path($exploded_slug) {
        //make sure that the slug is in a proper format for parsing
        return (sizeof($exploded_slug) >= 3 && in_array($this->default_results_slug, $exploded_slug));
    }

    private function is_relevant_general_results_path($exploded_slug) {
        $default_slug_index = $this->get_default_slug_index($exploded_slug);
        //make sure that the slug is in a proper format for parsing
        return (sizeof($exploded_slug) >= 2 && in_array($this->default_results_slug, $exploded_slug) && empty($exploded_slug[$default_slug_index + 2]));
    }

    private function get_base_slug_if_exists(){
        return empty($this->base_slug) ? "" : str_replace(array('.', ' ', '/'), '_',$this->base_slug)."/";
    }

    private function is_correct_date($date_string) {
        $date_format = preg_match('/\d{2}[-]\d{2}[-]\d{4}$/', $date_string) == 1;
        return $date_format;
    }

    private function get_default_slug_index($exploded_slug) {
        if(($index = array_search($this->default_slug, $exploded_slug)) === false) {
            $index = array_search($this->default_results_slug, $exploded_slug);
        }
        return $index;
    }

    private function race_expired($race) {
        return $this->date_time_has_passed($race['date'], $race['time']);
    }

    private function date_time_has_passed($date, $time) {
        $race_time = strtotime($this->swap_date_format($date). $time);
        $now = time();
        return $now > $race_time;
    }

    public function retrieve_race_data_from_url($slug) {
        $exploded_slug = explode("/", $slug);
        if(!($default_slug_index = array_search($this->default_slug, $exploded_slug))){
            $default_slug_index = array_search($this->default_results_slug, $exploded_slug);
        }
        $exploded_course_time = explode("-", $exploded_slug[$default_slug_index + 2]);
        if($exploded_course_time > 2){
            $race['title'] = $exploded_course_time[2];
        }
        $time = $exploded_course_time[1];
        $course = $exploded_course_time[0];
        $race['date'] = $this->swap_date_format($exploded_slug[$default_slug_index + 1]);
        $race['time'] = substr_replace($time, ':', 2, 0).":00";
        $race['course'] = ucwords($this->replace_underscores_with_spaces($course));
        return $race;
    }

    public function set_translations(){
        $translations = WCMSRacecardsUtils::translate_url_params();
        $this->default_slug = $translations[0]['value'] ? strtolower($translations[0]['value']) : 'racecards';
        $this->default_results_slug = $translations[1]['value'] ? strtolower($translations[1]['value']) : 'results';
        $this->default_tomorrow_slug = $translations[2]['value'] ? strtolower($translations[2]['value']) : 'tomorrow';
    }

    public function retrieve_date_from_url($slug) {
        $exploded_slug = explode("/", $slug);
        if(!($default_slug_index = array_search($this->default_slug, $exploded_slug))){
            $default_slug_index = array_search($this->default_results_slug, $exploded_slug);
        }
        return $this->swap_date_format($exploded_slug[$default_slug_index + 1]);
    }

    public function build_slug_for_post($post_id) {
        $slug = $this->get_base_slug_if_exists().$this->build_according_to_page_post_type($post_id);
        update_post_meta($post_id, $this->slug_db_meta_key, $slug);
    }

    public function get_url_slug(){
        return trim(parse_url(add_query_arg(array()), PHP_URL_PATH), '/');
    }

    public function set_all_racecards_posts_and_pages_permalinks_with_base_slug(){
        foreach ($this->all_racecards_posts_and_pages_ids as $post_id){
            $this->build_slug_for_post($post_id);
        }
    }

    public function parse_url() {
        $slug = $this->get_url_slug();
        if ( $this->is_relevant_path($slug) ) {
            $exploded_slug = explode("/", $slug);
            $result_slug = explode("/", $slug)[1];
            $race = $this->retrieve_race_data_from_url($slug);
            if(self::is_result_general_slug($exploded_slug)) {
                $permitted_dates = WCMSRacecardsUtils::block_no_results_dates_url();
                if(!in_array($race['date'], $permitted_dates)) {
                    locate_template('404.php', true);
                    exit();
                }
            }
            $heat_data = WCMSRacecardsUtils::get_heat_data($race);
            if(count($exploded_slug) > 3 || (count($exploded_slug) === 3 && (!isset($this->base_slug) || trim($this->base_slug) === ''))) {
                if($heat_data === null) {
                    locate_template('404.php', true);
                    exit();
                } elseif ($heat_data->data[0]->title && $result_slug === 'results') {
                    $search  = array(' ', '/', '-', '"', '\'');
                    $replace = array('_', '_', '_', '', '');
                    $title_underscore_form = strtolower(str_replace($search, $replace, $heat_data->data[0]->title));
                    $title_dash_form = strtolower(str_replace(' ', '-', $heat_data->data[0]->title));
                    $base_dash_form = strtolower($heat_data->data[0]->course).'-'.str_replace(':','',rtrim($heat_data->data[0]->time, "00")).'-';
                    $exploded_time_title_part = explode("-", $exploded_slug[3]);
                    $title_part = $exploded_time_title_part[count($exploded_time_title_part)-1];
                    if($title_part !== $title_underscore_form && str_replace('\\','',$exploded_slug[3]) != $base_dash_form.$title_dash_form) {
                        locate_template('404.php', true);
                        exit();
                    }
                }
            } else {
                $date_from_url = new DateTime($race['date']);
                $today = new DateTime("midnight");
                $interval_forward = $date_from_url->diff($today)->format("%r%a");
                $one_year_ago = new DateTime("midnight");
                $one_year_ago->modify('-1 year');
                $interval_backward = $date_from_url->diff($one_year_ago)->format("%r%a");
                if(intval($interval_forward) < 0 || intval($interval_backward) > 0) {
                    locate_template('404.php', true);
                    exit();
                }
            }
            if(!empty($race_id = ($heat_data->data[0])->raceId)){
                $race_results = WCMSRacecardsUtils::get_results_with_limiter(array('race_id' => $race_id));
                if(WCMSRacecardsUtils::has_results($race_results->data)){
                    header("Location: " . "/".$this->get_base_slug_if_exists().$this->default_results_slug."/race?race_id=".(WCMSRacecardsUtils::get_heat_data($race)->data[0])->raceId); /* Redirect browser */
                    exit();
                }
                // load the file if exists
                else if(!$this->is_there_a_post_for_this_race($race_id)){
                    $load =  locate_template('single-horse-race-card.php', true);
                    if ($load) {
                        exit(); // just exit if template was found and loaded
                    }
                }
            }else{ //meaning that this is a results-general page
                $load =  locate_template('results-general.php', true);
                if ($load) {
                    exit(); // just exit if template was found and loaded
                }
            }
        }
    }

    public function is_result_general_slug($slug_arr) {
        return $slug_arr[0] === $this->base_slug &&
               $slug_arr[1] === $this->default_results_slug &&
               preg_match('/\d{2}-\d{2}-\d{4}$/', $slug_arr[2]) == 1;
    }

    public function get_race_page_base_link($date) {
        return $this->get_base_slug_if_exists().$this->default_slug."/".$this->swap_date_format($date);
    }

    public function get_today_page_link() {
        return $this->get_base_slug_if_exists().$this->default_slug;
    }

    public function get_tomorrow_page_link() {
        return $this->get_base_slug_if_exists().$this->default_slug."/".$this->default_tomorrow_slug;
    }

    public function get_results_general_page_link() {
        return $this->get_base_slug_if_exists().$this->default_results_slug;
    }

    public function get_results_race_page_base_link_for_date($date) {
        return $this->get_base_slug_if_exists().$this->default_results_slug."/".$this->swap_date_format($date);
    }
}

