<?php
/**
 * Created by PhpStorm.
 * User: eliran.a
 * Date: 2/4/2019
 * Time: 12:27 PM
 */

class WCMSRacecardsUtils
{
    static function get_races_data($date) {
        $races_data = send_request_to_racecards_service(array('action' => 'pa_card_meetings', 'date' => $date, 'sport_type' => 'Horse_Racing'));
        return $races_data;
    }

    static function get_all_non_expired_races(){
        $races_data = send_request_to_racecards_service(array('action' => 'get_non_expired_meetings'));
        return $races_data;
    }

    static function get_race_by_id($race_id){
        $race_data = send_request_to_racecards_service(array('action' => 'get_race_by_id', 'race_id' => $race_id));
        return $race_data;
    }

    static function get_heat_data($race) {
        $race_data = send_request_to_racecards_service(array('action' => 'pa_meeting_details', 'date' => $race['date'], 'event' => $race['course'], 'time' => $race['time'] ));
        return $race_data;
    }

    static function get_results_with_limiter($param=array()) {
        $race_data = send_request_to_racecards_service(array('action' => 'get_results_with_limiter', 'date' => $param['date'], 'race_id' => $param['race_id'], 'meeting_id' => $param['meeting_id'], 'limit' => $param['limit'] ));
        return $race_data;
    }

    static function get_race_heats($meeting_id, $results = null) {
        $heats_data = send_request_to_racecards_service(array('action' => 'pa_meeting_heats', 'meeting_id' => $meeting_id ));
        $heats = array();
        foreach ($heats_data->data as $heat){
            $heat_data = array();
            $heat_data['time'] = $heat->time;
            $heat_data['title'] = $heat->title;
            $heat_data['has_results'] = $results[$heat->time];
            array_push($heats, $heat_data);
        }
        return $heats;
    }

    static function get_horses_for_race($raceId){
        $horse_details_data = send_request_to_racecards_service(array('action' => 'pa_race_horses_details', 'raceId' => $raceId));
        return $horse_details_data;
    }

    static function get_relevant_results_for_date($date){
        if(!empty($races_data = self::get_results_with_limiter(array('date'=>$date, 'limit'=>3)))){
            $formatted_races_data = self::populate_context_with_formatted_races($races_data, IS_LIVE);
        }else{
            $formatted_races_data = false;
        }

        return $formatted_races_data;
    }

    //determine if a date string is of a certain date format
    static function validateDate($date, $format = 'Y-m-d')
    {
        $d = DateTime::createFromFormat($format, $date);
        // The Y ( 4 digits year ) returns TRUE for any integer with any number of digits so changing the comparison from == to === fixes the issue.
        return $d && $d->format($format) === $date;
    }

    static function get_relevant_date_for_results_page($date){
        if(empty($date)){
            $date = date("Y-m-d");

            $response = self::get_most_recent_date_with_results();
            if($response->success === true && self::validateDate($date_string = $response->data->date, "Y-m-d") ){
                $date = $date_string;
            }
        }

        return $date;
    }

    static function populate_context_with_formatted_races($races_raw_data, $is_live_race){
        $formatted_races = array();
        if($races_raw_data->data[0]) {
            $results = self::create_has_results_array($races_raw_data->data[0]->date);
            $race_has_results_today = self::create_has_results_array_for_racing_day($results);
        } else {
            $race_has_results_today = null;
        }
        if($is_live_race){
            foreach($races_raw_data->data as $venue){
                if(empty($formatted_races[$venue->course]['conditions'])){
                    $formatted_races[$venue->course]['conditions'] = $venue->advancedGoing;
                }
                if(empty($formatted_races[$venue->course]['name'])){
                    $formatted_races[$venue->course]['name'] = $venue->course;
                }
                $formatted_races[$venue->course]['heats'] = self::get_race_heats($venue->meetingId, $race_has_results_today);
            }
        }else{
            foreach($races_raw_data->data as $venue){
                if(empty($formatted_races[$venue->course]['heats'])){
                    $formatted_races[$venue->course]['heats'] = array();
                }
                if(empty($formatted_races[$venue->course]['venue_name'])){
                    $formatted_races[$venue->course]['venue_name'] = $venue->course;
                }
                if(empty($formatted_races[$venue->course]['heats'][$venue->time])){
                    $formatted_races[$venue->course]['heats'][$venue->time] = array();
                    array_push($formatted_races[$venue->course]['heats'][$venue->time], array());
                }
                $formatted_races[$venue->course]['heats'][$venue->time]['name'] = $venue->raceName;
                $formatted_races[$venue->course]['heats'][$venue->time]['time'] = $venue->time;
                $formatted_races[$venue->course]['heats'][$venue->time]['has_results'] = $race_has_results_today[$venue->time];
                if(empty($formatted_races[$venue->course]['heats'][$venue->time]['winners'])){
                    $formatted_races[$venue->course]['heats'][$venue->time]['winners'] = array();
                }
                array_push($formatted_races[$venue->course]['heats'][$venue->time]['winners'], $venue->horseName);
            }
        }
        return $formatted_races;
    }

    static function get_page_management_menu($page_type) {
        $url_string = '<script>window.location.href="edit.php?s&post_status=all&post_type=page&action=-1&m=0&lang=cy&page_template=' . $page_type . '&filter_action=Filter&paged=1&action2=-1"</script>';
        print($url_string);
    }

    static function get_post_management_menu($post_type) {
        $url_string = '<script>window.location.href="edit.php?post_type=' . $post_type . '"</script>';
        print($url_string);
    }

    /* Handle Singleton pages functionality */
    static function count_pages_of_template($template_type) {
        global $wpdb;
        $sql = "SELECT COUNT(*) as total
            FROM `wp_posts` as p JOIN `wp_postmeta` as m ON p.ID = m.post_id
            WHERE p.post_type = 'page' AND p.post_status = 'publish' AND m.meta_key = '_wp_page_template' AND m.meta_value = '{$template_type}'";
        $result = $wpdb->get_results($sql);
        return $result;
    }

    static function is_singleton_page($template_type) {
        $page_count = self::count_pages_of_template($template_type);
        return intval($page_count[0]->total) > 1 ? true : false;
    }

    static function singleton_admin_logic($new_status, $old_status, $post) {
        require_once RACECARDS_PLUGIN_PATH.'dynamic_generator/common-arrays.php';
        if($new_status === 'publish' && $post->post_type === 'page') {
            foreach ($singleton_page_types as $pt => $pt_title) {
                if ($post->page_template === $pt && self::is_singleton_page($pt)) {
                    wp_block_publishing($post->ID, $pt_title);
                    break;
                }
            }
        }
    }

    static function wp_block_publishing($post_id, $page_name) {
        wp_delete_post( $post_id, true );
        wp_die('Sorry, you are not allowed to create more than one instance of ' . $page_name);
    }

    /**
     * This function is used to recombine acf repeater field after exploded by get_post_meta()
     * @param $_cf - Array, Post customfields (generated using get_post_meta())
     * @param $field_label - String, ACF field label name
     * @param $repeater_field_label - array, ACF repeater fields labels
     */
    static function acf_repeater_with_several_fields_to_array( $_cf, $field_label, $repeater_field_labels ){
        $result = array();
        $limit = is_array( $_cf[$field_label] ) ? $_cf[$field_label][0] : $_cf[$field_label];
        for ($i=0; $i < $limit; $i++ ){
            for($j=0 ; $j < sizeof($repeater_field_labels) ; $j++){
                if ( !empty ( $_cf[$field_label.'_'.$i.'_'.$repeater_field_labels[$j]] ) ){
                    $result[$i][$repeater_field_labels[$j]] = $_cf[$field_label.'_'.$i.'_'.$repeater_field_labels[$j]];
                }
            }
        }
        return $result;
    }

    static function get_brands() {
        global $wpdb;
        $wp_posts = $wpdb->prefix . 'posts';
        $type = 'brand';
        $query = "SELECT `ID`, `post_title` FROM `$wp_posts` WHERE `post_type`='$type'";
        $response = $wpdb->get_results($query);
        return $response;
    }

    static function get_aff_links_obj($brand_id) {
        global $wpdb;
        $wp_default_links_sets = $wpdb->prefix . 'default_links_sets';
        $query = "SELECT  `id_ls`, `pretty_link`, `brand_id` FROM `$wp_default_links_sets`";
        if ($brand_id){
            $query = $query . " WHERE `brand_id` = '$brand_id'";
        }
        $response = $wpdb->get_results($query);
        return $response;
    }

    static function call_scripts_for_plugin_pages(){
        $wp_content_path = dirname( __FILE__ , 3).'/';

        wp_enqueue_script( 'mCustomScrollbar', plugins_url( $wp_content_path . 'wcms_widgets/jquery.mCustomScrollbar.concat.min.js'), array('jquery'), '', true);
        wp_enqueue_script( 'racecards_front_scripts', plugins_url( $wp_content_path . 'wcms_racecards/js/wcms_racecards.js'), array('jquery','widgets_scripts'), '', true);
    }


    /* Merge horse details with his result details and sort horses by standings (positions) */
    static function sort_horses_array_by_standings($standings_arr, $horses_arr) {
        $result = array();
        foreach ($standings_arr as $horse_standings) {
            $curr_horse_standings_id = $horse_standings->horseId;
            $pos_in_horse_id = self::find_id_in_horses_arr($curr_horse_standings_id, $horses_arr);
            if($pos_in_horse_id !== null) {
                $curr_horse = $horses_arr[$pos_in_horse_id];
                $obj_merged = (object) array_merge((array) $horse_standings, (array) $curr_horse);
                array_push($result, $obj_merged);
            }
        }
        return $result;
    }

    /* Helps sorting by standings */
    static function find_id_in_horses_arr($id, $horses_arr) {
        $result = null;
        for($i = 0; $i < count($horses_arr); $i++) {
            if($horses_arr[$i]->horseId == $id) {
                $result = $i;
                break;
            }
        }
        return $result;
    }

    /* Checks if the results of the race are ready in the DB */
    static function has_results($results) {
        if($results === null) {
            return false;
        }
        foreach ($results as $curr) {
            $finish_pos = $curr->finishPos;
            if($finish_pos !== null) {
                return true;
            }
        }
        return false;
    }

    static function create_has_results_array_for_racing_day($race_results_grouped) {
        $race_has_results = array();
        foreach ($race_results_grouped as $results) {
            $race_has_results[$results[0]->time] = self::has_results($results);
        }
        return $race_has_results;
    }

    /* Group an array according to a certain column passed as $key */
    static function group_by($key, $data) {
        $result = array();
        foreach($data as $element) {
            $result[$element->{$key}][] = $element;
        }
        return $result;
    }

    static function arrange_horses_data_into_array($horse_data, $is_live){
        $horse_details_array = array();
        $i = 0;
        foreach ($horse_data as $horse) {
            $i++;
            $current_horse_data = array();
            /* Horse name, number, jockey, silk, trainer */
            $current_horse_data['horse_id'] = $horse->horseId;
            $current_horse_data['horse_name'] = $horse->name;
            $current_horse_data['horse_number'] = $is_live ? $horse->clothNumber : $horse->finishPos;
            $current_horse_data['horse_jockey'] = $horse->jockeyName;
            $current_horse_data['horse_jockey_silk'] = array('src'=>empty($horse->jockeySilk) ? '' : 'data:image/gif;base64,'.$horse->jockeySilk, 'alt'=>"Jockey's Silk", 'title'=>$i);
            $current_horse_data['horse_trainer'] = $horse->trainerName;

            /* Horse form, weight, age */
            $current_horse_data['horse_form'] = $horse->figures[0];
            $current_horse_data['horse_weight'] = str_replace(" ","-",$horse->weightText);
            $current_horse_data['horse_age'] = $horse->ageYears;
            /* Horse official rate */
            $current_horse_data['horse_official_rate'] = $horse->officialRating;

            /* Horse lane */
            $current_horse_data['horse_lane'] = $horse->drawnStall;

            /* Race Results (for results pages only) */
            if(!$is_live)
                $current_horse_data['commentary'] = $horse->closeUpComment;

            array_push($horse_details_array, $current_horse_data);
        }
        return $horse_details_array;
    }

    static function decrement_day($date){
        $date = strtotime("-1 day", strtotime($date));
        return date("Y-m-d", $date);
    }

    static function set_race_result_context($race_data){
        $context = array();
        $horses = self::get_horses_for_race($race_data->raceId);
        $race_results_today_grouped = self::create_has_results_array($race_data->date);
        $race_has_results_today = self::create_has_results_array_for_racing_day($race_results_today_grouped);
        $race_results = $race_results_today_grouped[$race_data->raceId];

        //Send indication of whether or not the results are ready in the DB
        $context['has_results_arr'] = $race_has_results_today;

        $horses_with_standings = self::sort_horses_array_by_standings($race_results, $horses->data);
        //get settings from plugin's settings page into as object
        $plugin_settings = get_racecards_settings();

        $context['horses_arr'] = self::arrange_horses_data_into_array($horses_with_standings, false);
        $context['widgets_arr'] = array_fill(0, $race_data->maxRunners, array('affiliate_url'=>$plugin_settings['aff_link']));
        $context['widget_layout'] = 'Automatic Pages';
        $context['automatic_page_type'] = 'results';
        $context['generic_silk'] = $plugin_settings['generic_silk'];

        //translations
        $context['trans_no_rc'] = TRANS_NO_RC;
        $context['trans_silk'] = TRANS_SILK;
        $context['trans_jockey'] = TRANS_JOCKEY;
        $context['trans_trainer'] = TRANS_TRAINER;
        $context['trans_form'] = TRANS_FORM;
        $context['trans_wgt'] = TRANS_WGT;
        $context['trans_age'] = TRANS_AGE;
        $context['trans_or'] = TRANS_OR;
        $context['trans_no'] = TRANS_NO;

        return $context;
    }

    static function fetch_race_results(){
        $context = array();
        $race = array();

        $race['time'] = $_GET['time'];
        $race['date'] = $_GET['date'];
        $race['course'] = $_GET['course'];
        $race_data = self::get_heat_data($race)->data[0];
        $context = array_merge($context, self::set_race_result_context($race_data));

        $template = Timber::fetch(ABSPATH . 'wp-content/plugins/wcms_widgets/view-twig/conversion_table/race_cards_automatic_pages.twig', $context, false);
        return $template;
    }

    static function fetch_no_results_dates(){
        $result = send_request_to_racecards_service(array('action' => 'get_no_results_dates'))->data;
        $dates_with_results_array = array_map(function ($object) {
                $datetime = new DateTime($object->date);
                $datetime->modify('-1 day');
                return $datetime->format('Y-m-d');
            }, $result);
        return json_encode($dates_with_results_array);
    }

    static function block_no_results_dates_url(){
        $result = send_request_to_racecards_service(array('action' => 'get_no_results_dates'))->data;
        $dates_with_results_array = array_map(function ($object) { return $object->date; }, $result);
        $datetime = new DateTime();
        array_push($dates_with_results_array, $datetime->format('Y-m-d'));
        return $dates_with_results_array;
    }

    static function create_has_results_array($date) {
        $race_results_today = self::get_results_with_limiter(array('date'=>$date));
        return self::group_by('raceId', $race_results_today->data);
    }

    static function get_results_general_page_id(){
        global $wpdb;
        $query = "SELECT post_id FROM `wp_postmeta` WHERE meta_key = '_wp_page_template' and meta_value = 'results-general.php'";
        $results = $wpdb->get_results($query);
        return $results;
    }

    static function translate_url_params() {
//    if( function_exists('icl_register_string') ) {
//        $translation_ids = array(
//            'racecards' => icl_register_string('wcms_racecards', '', 'Racecards'),
//            'results' => icl_register_string('wcms_racecards', '', 'Results'),
//            'tomorrow' => icl_register_string('wcms_racecards', '', 'Tomorrow')
//        );
//        $translation_ids_lst = implode(',', array_values($translation_ids));
//        global $wpdb;
//        $query = 'SELECT * FROM `wp_icl_string_translations` WHERE `string_id` IN (' . $translation_ids_lst . ')' . " AND `language` = '" . ICL_LANGUAGE_CODE . "'";
//        $results = $wpdb->get_results($query, ARRAY_A);
//        $result = array();
//        foreach ($translation_ids as $translation_name=>$translation_id) {
//            $index_in_results = array_search($translation_id,array_column($results, 'string_id'));
//            if($index_in_results === false) {
//                array_push($result, array('value'=>null));
//            }
//            else { array_push($result, $results[$index_in_results]); }
//        }
//        return $result;
//    }
        return array('racecards'=>'racecards', 'results'=>'results', 'tomorrow'=>'tomorrow');
    }

    static function get_a_singleton_page_id_by_type($page_type){
        return get_pages(array('meta_key'=>'_wp_page_template', 'meta_value'=>$page_type.FILE_EXTENSION))[0]->ID;
    }

    private static function get_most_recent_date_with_results()
    {
        $date = send_request_to_racecards_service(array('action' => 'get_last_result_date'));
        return $date;
    }
}