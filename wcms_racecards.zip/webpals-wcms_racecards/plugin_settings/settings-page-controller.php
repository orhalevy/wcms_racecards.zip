<?php

define('WCMS_RACECARDS_DOCUMENT_ROOT_PATH', rtrim($_SERVER['DOCUMENT_ROOT'], '/') . '/');

if(isset($_POST['action']) && !empty($_POST['action'])) {
    $action = $_POST['action'];
    switch($action) {
        case 'aff_links' : get_aff_links($_POST['brand_id']); break;
        case 'save_racecards_settings' : save_racecards_settings(); break;
    }
}

function wp_load() {
    define('SHORTINIT', true);
    require_once( WCMS_RACECARDS_DOCUMENT_ROOT_PATH.'wp-load.php' );
}

function get_aff_links($brand_id) {
    wp_load();
    require_once "../services/WCMSRacecardsUtils.php";
    $response = WCMSRacecardsUtils::get_aff_links_obj($brand_id);
    echo json_encode($response);
    die();
}

function save_racecards_settings() {
    wp_load();
    require_once(WCMS_RACECARDS_DOCUMENT_ROOT_PATH . 'wp-includes/formatting.php');
    update_option('racecards_client[base_slug]',$_POST['fields']['base_slug'], false);
    update_option('racecards_client[select_brand]',$_POST['fields']['brand_id'], false);
    update_option('racecards_client[select_brand_val]',$_POST['fields']['brand_name'], false);
    update_option('racecards_client[aff_link]',$_POST['fields']['aff_link'], false);
    update_option('racecards_client[compliance_checkbox]',$_POST['fields']['compliance'], false);
    update_option('racecards_client[sidebar_location]',$_POST['fields']['sidebar_location'], false);
    update_option('racecards_client[generic_content]',$_POST['fields']['generic_content'], false);
    update_option('racecards_client[h1_title]',$_POST['fields']['h1_title'], false);
    update_option('racecards_client[introduction_text]',$_POST['fields']['introduction_text'], false);
    update_option('racecards_client[generic_silk]',$_POST['fields']['generic_silk'], false);
}