<?php
wp_enqueue_script( 'racecards_scripts', plugins_url( 'wcms_racecards/js/settings_page_script.js'), array('jquery'), '', true);

/* Build template fields */
function settings_page_template($group) {
    /* Register our settings */
    $option_name = 'racecards_service_option_name';

    register_setting( $group, $option_name );
    add_settings_section(
        'section_1', // ID
        'URL Structure', // Title
        'racecards_render_section', // print output
        'racecards_client' // menu slug
    );
    add_settings_field(
        'base_slug',
        'Base Slug',
        'base_slug',
        'racecards_client',
        'section_1'
    );
    add_settings_section(
        'section_2',
        'Featured Brand',
        'racecards_render_section',
        'racecards_client'
    );
    add_settings_field(
        'select_brand',
        'Brand to feature on the Race pages',
        'select_brand',
        'racecards_client',
        'section_2'
    );
    add_settings_field(
        'aff_link',
        'Affiliate Link',
        'aff_link',
        'racecards_client',
        'section_2'
    );
    add_settings_field(
        'compliance_checkbox',
        'Add Compliance additional content',
        'compliance_checkbox',
        'racecards_client',
        'section_2'
    );
    add_settings_section(
        'section_3',
        'Sidebar location - for the Race pages',
        'racecards_render_section',
        'racecards_client'
    );
    add_settings_field(
        'sidebar_location',
        'Location of sidebar',
        'sidebar_location',
        'racecards_client',
        'section_3'
    );
    add_settings_section(
        'section_4',
        'Generic content - for the Race pages',
        'racecards_render_section',
        'racecards_client'
    );
    add_settings_field(
        'generic_content',
        'Activate the Generic content function for the Race pages',
        'generic_content',
        'racecards_client',
        'section_4'
    );
    add_settings_field(
        'h1_title',
        'H1 title',
        'h1_title',
        'racecards_client',
        'section_4'
    );
    add_settings_field(
        'introduction_text',
        'Introduction text',
        'introduction_text',
        'racecards_client',
        'section_4'
    );
    add_settings_field(
        'generic_silk',
        'Upload a generic Silk',
        'generic_silk',
        'racecards_client',
        'section_4'
    );
}

/* Field handlers */
function base_slug() {
    $options = get_option( 'racecards_client[base_slug]' );
    $html = "<input id='base_slug' class='settings-collect' type='text' style='margin-left: -10%; width: 40%;' name='racecards_client[base_slug]' value='$options''/>";
    echo $html;
}

function select_brand() {
    $brands = WCMSRacecardsUtils::get_brands();
    $html = "<select id='select_brand' class='settings-collect' name='racecards_client[select_brand]'>" . '<option value="select_brand">Select Brand</option>' . render_dropdown_options($brands) . '</select>';
    echo $html;
}

function aff_link() {
    $options = get_option( 'racecards_client[select_brand]' );
    $option_aff_link = get_option( 'racecards_client[aff_link]' );
    $html = "<select id='select_aff_link' class='settings-collect' name='racecards_client[select_brand]'>" . render_links_dropdown_options($options, $option_aff_link) . "</select>";
    echo $html;
}

function compliance_checkbox() {
    $options = get_option( 'racecards_client[compliance_checkbox]' );
    $checked = $options == 1 ? $checked = 'checked' : '';
    $html = "<input type='checkbox' id='compliance' class='settings-collect' name='racecards_client[compliance_checkbox]' " . $checked . "/>";
    echo $html;
}

function sidebar_location() {
    $options = get_option( 'racecards_client[sidebar_location]' );
    if ($options == 'left') { $right_checked = ''; $left_checked = 'checked'; }
    else { $right_checked = 'checked'; $left_checked = ''; }
    $html = "<input type='radio' name='sidebar_location' class='settings-collect' value='right_sidebar'" . $right_checked . "/>Right sidebar<br><input type='radio' name='sidebar_location' class='settings-collect' value='left_sidebar'" . $left_checked . "/>Left sidebar";
    echo $html;
}

function generic_content() {
    $options = get_option( 'racecards_client[generic_content]' );
    $checked = $options == 1 ? $checked = 'checked' : '';
    $html = "<input type='checkbox' id='generic_content' class='settings-collect' name='racecards_client[generic_content]' " . $checked . "/>";
    echo $html;
}

function h1_title() {
    $options = get_option( 'racecards_client[h1_title]' );
    $html = "<input id='h1_title' class='settings-collect' type='text' style='margin-left: -10%; width: 40%;' name='racecards_client[h1_title]' value='$options''/>";
    echo $html;
}

function introduction_text() {
    $options = get_option( 'racecards_client[introduction_text]' );
    $args = array("textarea_name" => "racecards_client[introduction_text]", "textarea_rows" => get_option('default_post_edit_rows', 5), "media_buttons" => false, "editor_class" => "settings-collect");
    wp_editor( $options, "introduction", $args );
}

function generic_silk() {
    $options = get_option( 'racecards_client[generic_silk]' );
    $display = $options == "" ? 'style="display: none;"' : "";
    $display_none = $options == "" ? 'display: none;' : "";
    $html = '<input type="file" id="silk_uploader" accept="image/*" onchange="readURL(this);"/><img id="silk" class="settings-collect" src="' . $options . '" alt="silk image" ' . $display . '/>';
    $html = $html . '<input type="button" class="remove_silk" value="Remove Silk image" onclick="removeImage()" style="margin-right: 1%;margin-left: 2%;' . $display_none . '"/><span class="remove_silk" ' . $display . '>' . '<b>Image will be removed after clicking "save changes" only!</b></span>';
    $script = get_silk_script();
    echo $html . $script;
}

function print_placeholders_manual() {
    echo '<div style="color: green; font-size: 2em;font-weight: 600;margin-top: 1%;" class="generic-activate">Placeholders which can be used as a generic content</div>
          <div style="font-size: 1.4em; margin-top: 0.7%;" class="generic-activate">{venue} - Presents the venue name</div>
          <div style="font-size: 1.4em; margin-top: 0.7%;" class="generic-activate">{race_time} - Presents the time which the race takes place</div>
          <div style="font-size: 1.4em; margin-top: 0.7%;" class="generic-activate">{race_date} - Presents the date which the race takes place</div>
          <div style="font-size: 1.4em; margin-top: 0.7%;" class="generic-activate">{race_title} - Presents the title (name) of the race</div>';
}

function render_dropdown_options($brands) {
    $selected_brand_id = get_option('racecards_client[select_brand]');
    $result = '';
    foreach ($brands as $brand) {
        $selected_brand_id == $brand->ID ? $selected = 'selected' : $selected = '';
        $option_string = '<option value="' . $brand->ID . '" ' . $selected . '>' . $brand->post_title . '</option>';
        $result = $result . $option_string;
    }
    return $result;
}

function render_links_dropdown_options($brand_id, $aff_link) {
    if($brand_id == false || $brand_id == '') {
        return "<option value='select_link'>Select Link</option>";
    }
    $response = WCMSRacecardsUtils::get_aff_links_obj($brand_id);

    $result = '';
    foreach ($response as $link_obj) {
        $aff_link == $link_obj->pretty_link ? $selected = 'selected' : $selected = '';
        $option_string = '<option value="' . $link_obj->brand_id . '" ' . $selected . '>' . $link_obj->pretty_link . '</option>';
        $result = $result . $option_string;
    }
    return $result;
}

function get_silk_script() {
    return '<script>function readURL(input) {
                            var silk = $("#silk");
                            var remover = $(".remove_silk");
                            if(input.value == "") {
                                silk.hide();
                                remover.hide();
                                return;
                            } else { 
                                silk.show();
                                remover.show();
                            }
                            if (input.files && input.files[0]) {
                                var reader = new FileReader();
                                reader.onload = function (e) {
                                    silk.attr("src", e.target.result);
                                };
                                reader.readAsDataURL(input.files[0]);
                            }
                        }
                        function removeImage() {
                          var silk = $("#silk");
                          silk.attr("src","");
                          silk.hide();
                        }
              </script>';
}