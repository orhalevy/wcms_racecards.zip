<?php

function get_racecards_settings() {
    global $wpdb;
    $wp_options = $wpdb->prefix . 'options';
    $query = "SELECT `option_name`, `option_value` FROM `$wp_options` WHERE `option_name` LIKE 'racecards_client[%]'";
    $response = $wpdb->get_results($query);
    $result = array();
    foreach ($response as $field) {
        $left_bracket_pos = strpos($field->option_name, '[');
        $right_bracket_pos = strpos($field->option_name, ']');
        $option_name = (substr($field->option_name, $left_bracket_pos + 1, $right_bracket_pos - $left_bracket_pos - 1));
        $result[$option_name] = $field->option_value;
    }
    return $result;
}

function intro_text_placeholders_replace($intro_text_str, $venue = '', $race_time = '', $race_date = '', $race_title = '') {
    $needles = array('{venue}', '{race_time}', '{race_date}', '{race_title}');
    $replacements = array($venue, $race_time, $race_date, $race_title);
    return str_replace($needles, $replacements, $intro_text_str);
}