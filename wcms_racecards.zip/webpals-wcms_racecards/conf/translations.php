<?php

define('TRANS_NO_RC', __('No_rc', 'wcms_racecards'));
define('TRANS_SILK', __('Silk', 'wcms_racecards'));
define('TRANS_HORSE', __('Horse', 'wcms_racecards'));
define('TRANS_JOCKEY', __('Jockey', 'wcms_racecards'));
define('TRANS_TRAINER', __('Trainer', 'wcms_racecards'));
define('TRANS_WGT',  __('Wgt', 'wcms_racecards'));
define('TRANS_FORM', __('Form', 'wcms_racecards'));
define('TRANS_AGE', __('Age', 'wcms_racecards'));
define('TRANS_OR',__('Or', 'wcms_racecards') );
define('TRANS_NO', __('No', 'wcms_racecards'));
define('TRANS_RECOMMENDED_BRAND', __('Recommended Brand', 'wcms_racecards'));
define('TRANS_TERMS_AND_CONDITIONS_APPLY', __("T&C’s Apply", 'wcms_racecards'));
define('TRANS_CTA_SPORT_BUTTON_TEXT', __("Button Text", 'wcms_racecards'));
define('TRANS_NO_DATA_MESSAGE', __('No Data Message','wcms_racecards'));
define('TRANS_BACK_TO_RESULTS', __("Back to results",'wcms_racecards'));
define('TRANS_RESULTS', __('Results','wcms_racecards'));
define('TRANS_RACE_CARDS', __('Race Cards','wcms_racecards'));
define('TRANS_BET_WITH', __('Bet With','wcms_racecards'));
define('TRANS_DESCRIPTION', __('Description','wcms_racecards'));
define('TRANS_TOMORROW', __('Tomorrow','wcms_racecards'));
define('TRANS_TODAY', __('Today','wcms_racecards'));
