<?php
/*
 * Template Name Posts: horse-race-card
 * Description: This part is optional, but helpful for describing the Post Template
 */

require_once RACECARDS_PLUGIN_PATH . 'plugin_settings/settings-page-api.php';

wp_enqueue_style( 'race_card', '/wp-content/plugins/wcms_racecards/css/race-card'. (enqueue_css_scripts::get_css_checkbox() ? '.min' : '') .'.css',array('wcms_widgets-style','style-default'));

global $post;
the_post();

$field_handler = new field_handler();
$context = $field_handler->set_context_array();
/*this require_once is here and not at the start of the file because controllers/today-page.php needs to know $context*/
require_once RACECARDS_PLUGIN_PATH.'controllers/race-page.php';

//check if there is a 'race-page.twig' inside the theme's views, otherwise, use the plugin's template
$twig_filename = 'race-page';
$twig_file_path = (file_exists(LOCAL_TWIG_PATH.$twig_filename.'.twig') ? LOCAL_TWIG_PATH : PLUGIN_TWIG_PATH).$twig_filename.'.twig';

$context['wysiwyg_widget_repeater'] = acf_repeater_with_several_fields_to_array(explode_cf(get_post_meta( $post->ID)),'widget_text_repeater', ['content_text_repeater', 'widget_repeater']);
$context['plugins_file_path'] = ABSPATH . 'wp-content/plugins/';
$context['trans_bet_with'] = __('Bet With', 'wcms_racecards');
$context['trans_description'] = __('description', 'wcms_racecards');

$object_id = get_queried_object_id();
/*
 * Action wcms_template_before_render
 * Used to set the page context to the cache for this page.
 * Change the context variable only BEFORE this action
 */
do_action( 'wcms_template_before_render', $context, $object_id, $twig_filename );

get_header();
Timber::render(array(ABSPATH . 'wp-content/plugins/wcms_racecards/views/' . $twig_filename . '.twig'), $context, array( 0 ), TimberLoader::CACHE_OBJECT);
get_footer();
