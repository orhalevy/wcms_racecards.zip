<?php
require_once('common-arrays.php');

/* Server paths */
$generator_folder = WP_CONTENT_PATH . 'plugins/wcms_racecards/dynamic_generator/';
$themes_folder = WP_CONTENT_PATH . 'themes/';

/* Loop through existing parents and generate page/post templates from the centralized pool inside the plugin */
foreach ($parents as $key => $value) {
    if(file_exists($themes_folder . $key))
        copy_files($generator_folder, $page_types, $themes_folder, $parents, $key);
}

function copy_files($generator_folder, $page_types, $themes_folder, $parents, $curr_parent) {
    foreach ($page_types as $key => $value) {
        copy($generator_folder . $page_types[$key] . '-copy.php', $themes_folder . $parents[$curr_parent] . '/' . $page_types[$key] . '.php');
        if(file_exists($themes_folder . $parents[$curr_parent] . '/' . $page_types[$key] . '.php')){
            chmod($themes_folder . $parents[$curr_parent] . '/' . $page_types[$key] . '.php',0755);
        }
    }
}