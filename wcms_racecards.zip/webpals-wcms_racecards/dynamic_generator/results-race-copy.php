<?php
/*
 * template name: Results Race
 */

require_once PLUGIN_DIR.'/functions.php';

wp_enqueue_style( 'race_cards_results_race', '/wp-content/plugins/wcms_racecards/css/results-race'. (enqueue_css_scripts::get_css_checkbox() ? '.min' : '') .'.css',array('wcms_widgets-style','style-default'));

global $post;
the_post();

$field_handler = new field_handler();
$context = $field_handler->set_context_array();

$wp_content_path = dirname( __FILE__ , 3).'/';
$race_cards_plugin_path = 'plugins/wcms_racecards/';

$object_id = get_queried_object_id();
$twig_filename = 'results-race';
$local_twig_path =  $wp_content_path.'themes/'. wp_get_theme().'/views/';
$plugin_twig_path = $wp_content_path.$race_cards_plugin_path.'views/';

$context['wysiwyg_widget_repeater'] = acf_repeater_with_several_fields_to_array(explode_cf(get_post_meta( $post->ID)),'widget_text_repeater', ['content_text_repeater', 'widget_repeater']);
$context['plugins_file_path'] = ABSPATH . 'wp-content/plugins/';

//check if there is a 'today-tomorrow-page.twig' inside the theme's views, otherwise, use the plugin's template
$twig_file_path = (file_exists($local_twig_path.$twig_filename.'.twig') ? $local_twig_path : $plugin_twig_path).$twig_filename.'.twig';
require_once $wp_content_path.$race_cards_plugin_path.'controllers/results-race.php';

/*
 * Action wcms_template_before_render
 * Used to set the page context to the cache for this page.
 * Change the context variable only BEFORE this action
 */
do_action( 'wcms_template_before_render', $context, $object_id, $twig_filename );
get_header();
Timber::render(array($twig_file_path), $context, array( 0 ), TimberLoader::CACHE_OBJECT);
get_footer();