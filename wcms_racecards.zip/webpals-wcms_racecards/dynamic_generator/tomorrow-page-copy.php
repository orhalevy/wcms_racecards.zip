<?php
/*
 * template name: Tomorrow Page
 */

require_once RACECARDS_PLUGIN_PATH . 'plugin_settings/settings-page-api.php';
require_once PLUGIN_DIR.'/functions.php';

wp_enqueue_style( 'race_cards_today_tomorrow', '/wp-content/plugins/wcms_racecards/css/today-tomorrow'. (enqueue_css_scripts::get_css_checkbox() ? '.min' : '') .'.css',array('wcms_widgets-style','style-default'));

global $post;
the_post();

$field_handler = new field_handler();
$context = $field_handler->set_context_array();
/*this require_once is here and not at the start of the file because controllers/today-page.php needs to know $context*/
require_once RACECARDS_PLUGIN_PATH.'controllers/tomorrow-page.php';

//check if there is a 'today-tomorrow-page.twig' inside the theme's views, otherwise, use the plugin's template
$twig_filename = 'today-tomorrow-page';
$twig_file_path = (file_exists(LOCAL_TWIG_PATH.$twig_filename.'.twig') ? LOCAL_TWIG_PATH : PLUGIN_TWIG_PATH).$twig_filename.'.twig';

$context['day'] = 'tomorrow';
$context['wysiwyg_widget_repeater'] = acf_repeater_with_several_fields_to_array(explode_cf(get_post_meta( $post->ID)),'widget_text_repeater', ['content_text_repeater', 'widget_repeater']);
$context['trans_tomorrow'] = __('Tomorrow', 'wcms_racecards');
$context['trans_today'] = __('Today', 'wcms_racecards');

$object_id = get_queried_object_id();
/*
 * Action wcms_template_before_render
 * Used to set the page context to the cache for this page.
 * Change the context variable only BEFORE this action
 */
do_action( 'wcms_template_before_render', $context, $object_id, $twig_filename );
get_header();
Timber::render(array($twig_file_path), $context, array( 0 ), TimberLoader::CACHE_OBJECT);
get_footer();