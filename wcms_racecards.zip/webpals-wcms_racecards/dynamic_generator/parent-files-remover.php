<?php
require_once('common-arrays.php');
$themes_folder = WP_CONTENT_PATH . 'themes/';

/* Loop through all parents and racecard's page types and remove them */
foreach ($parents as $parent_key => $parent_value) {
    foreach ($page_types as $page_key => $page_value) {
        $path = $themes_folder . $parent_key . '/' . $page_value . '.php';
        safe_delete_file($path);
    }
}

/* Verify the existence of every file in order to avoid E_WARNING generation and delete file */
function safe_delete_file($dest_file_path) {
    if(file_exists($dest_file_path)){
        unlink($dest_file_path);
    }
}