<?php

/* Holds all racecard's page types. Add new ones easily if needed */
$page_types = array(
    'today' => 'today-page',
    'tomorrow' => 'tomorrow-page',
    'race' => 'single-horse-race-card',
    'results_general' => 'results-general',
    'results_race' => 'results-race'
);

/* Holds all our current parents. Add new parents easily if needed */
$parents = array(
    'sports' => 'sports',
    'casino' => 'casino',
    'consumersreviews' => 'consumersreviews'
);

/* Holds all racecard's singleton pages. Add new ones easily if needed */
$singleton_page_types = array(
    'today-page.php' => 'Today Page.',
    'tomorrow-page.php' => 'Tomorrow Page.',
    'results-general.php' => 'Results General Page.',
    'results-race.php' => 'Results Race Page.'
);