<?php
require_once RACECARDS_PLUGIN_PATH.'conf/translations.php';

WCMSRacecardsUtils::call_scripts_for_plugin_pages();

global $racecards_url_handler;
$racecards_url_handler->set_all_racecards_posts_and_pages_permalinks_with_base_slug();

define('IS_LIVE', true);

$today = date("Y-m-d");

if(!empty($races_data = WCMSRacecardsUtils::get_races_data($today))){
    $context['races_data'] = WCMSRacecardsUtils::populate_context_with_formatted_races($races_data, IS_LIVE);
}else{
    $context['races_data'] = false;
}

add_filter( 'wpseo_breadcrumb_links', function($links) use ($context){
    $links = array_slice($links, 0, 1);
    array_push($links, array('text'=>$context['h1_title']));

    return $links;
});

$context['day'] = 'today';
$context['other_tab_link'] = $racecards_url_handler->get_tomorrow_page_link();
$context['race_page_base_link'] = $racecards_url_handler->get_race_page_base_link($today);
$context['date'] = $today;
$context['sync_now'] = date("Y-m-d H:i:s", time());
$context['automatic_page_type'] = 'race';
$context['results_race_page_base_link'] = $racecards_url_handler->get_results_race_page_base_link_for_date($today);
$context['results_page_link'] = $racecards_url_handler->get_results_general_page_link();
$context['trans_no_data_message'] = TRANS_NO_DATA_MESSAGE;
