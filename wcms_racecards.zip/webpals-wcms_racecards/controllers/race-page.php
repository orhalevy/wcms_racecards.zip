<?php
require_once RACECARDS_PLUGIN_PATH.'conf/translations.php';
WCMSRacecardsUtils::call_scripts_for_plugin_pages();

global $racecards_url_handler;
$racecards_url_handler->set_all_racecards_posts_and_pages_permalinks_with_base_slug();

define('IS_LIVE', true);

//if there is no race card assigned post for this specific race
if(empty($race_data = (WCMSRacecardsUtils::get_race_by_id(get_post_meta($post->ID, 'horse_race_id', true)))->data[0])){
    $race = $racecards_url_handler->retrieve_race_data_from_url($racecards_url_handler->get_url_slug());
    $race_data = WCMSRacecardsUtils::get_heat_data($race)->data[0];
}
$horses = WCMSRacecardsUtils::get_horses_for_race($race_data->raceId);

//Indicates of whether or not each race has results
$results_for_date_grouped = WCMSRacecardsUtils::create_has_results_array($race_data->date);
$race_has_results_today = WCMSRacecardsUtils::create_has_results_array_for_racing_day($results_for_date_grouped);

//get settings from plugin's settings page into as object
$plugin_settings = get_racecards_settings();

//get selected brand from settings object
$brand_square_logo_id = get_post_meta($plugin_settings['select_brand'], 'main_brand_logo', true);
$brand_square_logo = get_image_object($brand_square_logo_id);
$aff_link = get_site_url().'/'.$plugin_settings['aff_link'];

//populating fields for page context
$context['horses_arr'] = WCMSRacecardsUtils::arrange_horses_data_into_array($horses->data, IS_LIVE);
$context['race_heats'] = WCMSRacecardsUtils::get_race_heats($race_data->meetingId, $race_has_results_today);
$context['widgets_arr'] = array();
$context['widgets_arr'] = array_fill(0, $race_data->maxRunners, array('affiliate_url'=>$aff_link));
$context['disable_automatic'] = false;
$context['widget_layout'] = 'Automatic Pages';
$context['race_pitch_condition'] = $race_data->advancedGoing;
$context['title'] = $race_data->title;
$context['course'] = $race_data->course;
$context['time'] = $race_data->time;
$context['date'] = $race_data->date;
$context['selected_brand_logo'] = $brand_square_logo;
$context['aff_link'] = $aff_link;
$context['generic_silk'] = $plugin_settings['generic_silk'];

$context['race_page_base_link'] = $racecards_url_handler->get_race_page_base_link($race_data->date);
$context['sync_now'] = date("d-m-Y H:i:s", time());
$context['automatic_page_type'] = 'race';
$context['results_race_page_base_link'] = $racecards_url_handler->get_results_race_page_base_link_for_date($race_data->date);

if(empty($post->ID)){
    $context['sidebar_location'] = ($plugin_settings['sidebar_location'] == 'left') ? 'left_sidebar' : 'right_sidebar';
    ob_start();
    dynamic_sidebar('Horse Race Cards');
    $context['sidebar1'] = ob_get_clean();
    enqueue_css_scripts::get_sidebar_widgets_by_regex($context['sidebar1']);

    add_action('wpseo_head', function() use (&$racecards_url_handler, &$race_data) {
        $meta_desc_content = get_bloginfo('name') . " | " . "Get all the information you need about the ";
        $meta_desc_content .= $race_data->course . ", " . $race_data->title . ' track, horses and jockeys';
        $output  = '<title>'.TRANS_RACE_CARDS.': '.$race_data->title.'</title>'. "\n";
        $output .= '<meta name="description" content="' . $meta_desc_content . '"/>'. "\n";
        $output .= '<meta property="og:title" content=""/>'. "\n";
        echo $output;
    } );
} else { // Race has been taken over
    if(empty(get_post_meta($post->ID, '_yoast_wpseo_metadesc', true))) {
        add_action('wpseo_head', function() use (&$racecards_url_handler, &$race_data) {
            $meta_desc_content = get_bloginfo('name') . " | " . "Get all the information you need about the ";
            $meta_desc_content .= $race_data->course . ", " . $race_data->title . ' track, horses and jockeys';
            echo '<meta name="description" content="' . $meta_desc_content . '"/>'. "\n";
        } );
    }
}

if($plugin_settings['generic_content'] == "1"){
    if(!empty($plugin_settings['h1_title']) && empty($context['h1_title'])){
        $context['h1_title'] = intro_text_placeholders_replace(preg_replace('/class=".*?"/', '', $plugin_settings['h1_title']), $race_data->course, $race_data->time, $race_data->date, $race_data->title);
    }
    if(!empty($plugin_settings['introduction_text']) && empty($context['introduction_text'])){
        $context['introduction_text'] = intro_text_placeholders_replace(preg_replace('/class=".*?"/', '', $plugin_settings['introduction_text']), $race_data->course, $race_data->time, $race_data->date, $race_data->title);
    }
}

add_filter( 'wpseo_breadcrumb_links', function($links) use ($context, $race_data, $racecards_url_handler){
    define('WCMS_ACECARDS_PAGE_SUFFIX', '-page');
    define('WCMS_ACECARDS_PARENT_PAGE_TEMPLATE', ($race_data->date == date('Y-m-d', strtotime("+1 day", strtotime(date('Y-m-d'))))) ? 'tomorrow' : 'today');
    $parent_page_id = WCMSRacecardsUtils::get_a_singleton_page_id_by_type(WCMS_ACECARDS_PARENT_PAGE_TEMPLATE . WCMS_ACECARDS_PAGE_SUFFIX);
    $get_page_link_function_name = 'get_' . WCMS_ACECARDS_PARENT_PAGE_TEMPLATE . '_page_link';
    $parent_page_link = call_user_func(array($racecards_url_handler, $get_page_link_function_name));

    $links = array_slice($links, 0, 1);
    $links = array_merge($links, array(array('text'=>get_post_meta($parent_page_id, 'h1_title', true), 'url'=>get_site_url()."/".$parent_page_link), array('text'=>$race_data->title)));

    return $links;
} );

// get selected brand's compliance text
if($plugin_settings['compliance_checkbox'] == 1){
    if($context['compliance_checkbox'] = get_post_meta($plugin_settings['select_brand'],'t_c_text_check')[0]){
        $context['compliance_text'] = get_post_meta($plugin_settings['select_brand'],'t_c_text')[0];
    }
}

/* Translations */
$context['trans_no_rc'] = TRANS_NO_RC;
$context['trans_silk'] = TRANS_SILK;
$context['trans_horse'] = TRANS_HORSE;
$context['trans_jockey'] = TRANS_JOCKEY;
$context['trans_trainer'] = TRANS_TRAINER;
$context['trans_form'] = TRANS_FORM;
$context['trans_wgt'] = TRANS_WGT;
$context['trans_age'] = TRANS_AGE;
$context['trans_or'] = TRANS_OR;
$context['trans_no'] = TRANS_NO;
$context['trans_recommended_brand'] = TRANS_RECOMMENDED_BRAND;
$context['trans_terms_and_conditions_apply'] = TRANS_TERMS_AND_CONDITIONS_APPLY;
$context['trans_cta_sport_button_text'] = TRANS_CTA_SPORT_BUTTON_TEXT;