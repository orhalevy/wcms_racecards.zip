<?php
require_once RACECARDS_PLUGIN_PATH.'conf/translations.php';

WCMSRacecardsUtils::call_scripts_for_plugin_pages();

global $racecards_url_handler;
$racecards_url_handler->set_all_racecards_posts_and_pages_permalinks_with_base_slug();

define('IS_LIVE', false);

//Service calls
$race_data = WCMSRacecardsUtils::get_race_by_id($_REQUEST['race_id'])->data[0];
$context = array_merge($context, WCMSRacecardsUtils::set_race_result_context($race_data));

//results general's url. We use it for the go back button
$context['results_general_url'] = $racecards_url_handler->get_results_general_page_link();

//get selected brand from settings object
$brand_logo_id = get_post_meta($plugin_settings['select_brand'], 'main_brand_logo', true);
$brand_logo = get_image_object($brand_logo_id);
$context['selected_brand_logo'] = $brand_logo;

//populating fields for page context
$context['race_heats'] = WCMSRacecardsUtils::get_race_heats($race_data->meetingId, $context['has_results_arr']);
$context['race_pitch_condition'] = $race_data->advancedGoing;
$context['title'] = $race_data->title;
$context['course'] = $race_data->course;
$context['time'] = $race_data->time;
$context['date'] = $race_data->date;
$context['aff_link'] = $plugin_settings['aff_link'];
$context['race_page_base_link'] = $racecards_url_handler->get_race_page_base_link($race_data);
$context['sync_now'] = date("H:i:s", time());
$context['results_race_page_base_link_with_date'] = $racecards_url_handler->get_results_race_page_base_link_for_date($race_data->date);
$context['results_race_page_base_link'] = $racecards_url_handler->get_results_general_page_link();
$context['race_page_base_link'] = $racecards_url_handler->get_race_page_base_link($race_data->date);
$context['h1_title'] = intro_text_placeholders_replace(preg_replace('/class=".*?"/', '', get_post_meta($post->ID, 'h1_title', true)), $race_data->course, $race_data->time, $race_data->date, $race_data->title);
$context['introduction_text'] = intro_text_placeholders_replace(preg_replace('/class=".*?"/', '', get_post_meta($post->ID, 'introduction_text', true)), $race_data->course, $race_data->time, $race_data->date, $race_data->title);

/* Generate meta description for page, if one hasn't created via Yoast */
if(empty(get_post_meta($post->ID, '_yoast_wpseo_metadesc', true))) {
    add_action('wpseo_head', function() use (&$racecards_url_handler, &$race_data) {
        $content = get_bloginfo('name') . " | " . "Get the horse racing results for ";
        $content .= $race_data->course . ", " . $race_data->title;
        echo '<meta name="description" content="' . $content . '"/>';
    } );
}

add_filter( 'wpseo_breadcrumb_links', function($links) use ($context, $race_data, $racecards_url_handler){
    $results_general_page_id = WCMSRacecardsUtils::get_a_singleton_page_id_by_type('results-general');
    $results_general_page_link = $racecards_url_handler->get_results_general_page_link();

    $links = array_slice($links, 0, 1);
    $links = array_merge($links, array(array('text'=>get_post_meta($results_general_page_id, 'h1_title', true), 'url'=>get_site_url()."/".$results_general_page_link), array('text'=>$race_data->title)));

    return $links;
} );

// get selected brand's compliance text
if($plugin_settings['compliance_checkbox'] == 1){
    if($context['compliance_checkbox'] = get_post_meta($plugin_settings['select_brand'],'t_c_text_check')[0]){
        $context['compliance_text'] = get_post_meta($plugin_settings['select_brand'],'t_c_text')[0];
    }
}

/* Translations */
$context['trans_recommended_brand'] = TRANS_RECOMMENDED_BRAND;
$context['trans_terms_and_conditions_apply'] = TRANS_TERMS_AND_CONDITIONS_APPLY;
$context['trans_cta_sport_button_text'] = TRANS_CTA_SPORT_BUTTON_TEXT;
$context['back_to_results'] = TRANS_BACK_TO_RESULTS;
$context['trans_results'] = TRANS_RESULTS;
