<?php
define('IS_LIVE', false);
require_once RACECARDS_PLUGIN_PATH.'conf/translations.php';

WCMSRacecardsUtils::call_scripts_for_plugin_pages();
wp_enqueue_script( 'jquery-ui', plugins_url( 'wcms_racecards/js/jquery-ui.js'), array('jquery'), '', true);

global $racecards_url_handler;
$racecards_url_handler->set_all_racecards_posts_and_pages_permalinks_with_base_slug();
$date_parsed_from_url = $racecards_url_handler->retrieve_date_from_url($racecards_url_handler->get_url_slug());
$relevant_date = WCMSRacecardsUtils::get_relevant_date_for_results_page($date_parsed_from_url);

global $post;
$post_id = WCMSRacecardsUtils::get_results_general_page_id()[0]->post_id;
$post = get_post((int)$post_id, OBJECT);

if(!empty($date_parsed_from_url)) {
    add_action('wpseo_head', function() use (&$date_parsed_from_url) {
        $site_name = get_bloginfo('name');
        $date = (new DateTime($date_parsed_from_url))->format('d/m/Y');
        $meta_desc_content = 'Get the horse racing results for ' . $date . ' to place the best bet possible. ';
        $meta_desc_content .= "We've got you covered with all the UK horse racing results. Get Live Results on " . $site_name;
        $title = 'Horse Racing Results for: ';
        $title .= $date . " | " . $site_name;
        $output  = '<title>'.$title.'</title>'. "\n";
        $output .= '<meta name="description" content="' . $meta_desc_content . '"/>'. "\n";
        echo $output;
    } );
}

add_filter( 'wpseo_breadcrumb_links', function($links) use ($context){
    $links = array_slice($links, 0, 1);
    array_push($links, array('text'=>$context['h1_title']));

    return $links;
});

$context['races_data'] = WCMSRacecardsUtils::get_relevant_results_for_date($relevant_date);
$context['date'] = $relevant_date;
$context['trans_no_data_message'] = TRANS_NO_DATA_MESSAGE;
$context['results_race_page_base_link_with_date'] = $racecards_url_handler->get_results_race_page_base_link_for_date($relevant_date);
$context['results_race_page_base_link'] = $racecards_url_handler->get_results_general_page_link();
$context['trans_results'] = TRANS_RESULTS;
