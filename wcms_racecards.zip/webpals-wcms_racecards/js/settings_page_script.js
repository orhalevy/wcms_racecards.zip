// backend script


$ = jQuery.noConflict();
$(document).ready(function($) {

    /* Disable the user from adding HTML directly*/
    $("textarea[name='racecards_client[introduction_text]']").attr("disabled", true);

    /* Check if the generic content is checked and we should show it's fields  */
    genericContentToggle();

    /* When the selected brand is changed, the relevant affiliate links should load into the dropdown */
    $( "#select_brand" ).change(function() {
        if(this.value === 'select_brand') {
            $( "#select_aff_link" ).empty().append('<option value="select_aff_link">Select Link</option>');
            return;
        }
        var request = $.ajax({
            url: "/wp-content/plugins/wcms_racecards/plugin_settings/settings-page-controller.php",
            type: "post",
            data: {action: 'aff_links', brand_id: this.value}
        });
        request.done(function (response){
            $( "#select_aff_link" ).empty().append(createAffLinkOptions(JSON.parse(response)));
        });
    });

    /* Save changes - collect the fields and save in DB */
    $( "#submit" ).click(function() {
        var fieldsArray = collectSettingsData();
        var request = $.ajax({
            url: "/wp-content/plugins/wcms_racecards/plugin_settings/settings-page-controller.php",
            type: "post",
            data: {action: 'save_racecards_settings', fields: fieldsArray}
        });
    });

    /* Save changes - collect the fields and save in DB */
    $( "#generic_content" ).change(function() {
        genericContentToggle();
    });


    /* Create the options for the affiliate link dropdown */
    function createAffLinkOptions(data) {
        var result = ''; var i;
        for(i = 0; i < data.length; i++) {
            result += '<option value="' + data[i]['brand_id'] + '">' + data[i]['pretty_link'] + '</option>';
        }
        return result;
    }

    /* Collect values from fields */
    function collectSettingsData() {
        var fields = new Object();
        fields['base_slug'] = $("#base_slug").val();
        fields['brand_id'] = $("#select_brand").val();
        fields['brand_name'] = $("#select_brand option:selected").text();
        fields['aff_link'] = $("#select_aff_link option:selected").text();
        $("#generic_content").is(":checked") ? fields['generic_content'] = 1 : fields['generic_content'] = 0;
        $("#compliance").is(":checked") ? fields['compliance'] = 1 : fields['compliance'] = 0;
        $('input[name=sidebar_location]:checked').val() == 'right_sidebar' ? fields['sidebar_location'] = 'right' : fields['sidebar_location'] = 'left';
        fields['h1_title'] = $("#h1_title").val();
        fields['introduction_text'] = $('#introduction_ifr').contents().find("body").html();
        fields['generic_silk'] = $('#silk').attr('src');

        return fields;
    }

    /* Generic content checkbox handler */
    function genericContentToggle() {
        var genericActivate = $('.generic-activate');
        var title = $('#h1_title').parent().parent();
        var wysiwyg = $('#wp-introduction-wrap').parent().parent();
        var silk_section = $("#silk_uploader").parent().parent();
        if($( "#generic_content" ).is(":checked")) {
            genericActivate.show();
            title.show();
            wysiwyg.show();
            silk_section.show();
        } else {
            genericActivate.hide();
            title.hide();
            wysiwyg.hide();
            silk_section.hide();
        }
    }
});
