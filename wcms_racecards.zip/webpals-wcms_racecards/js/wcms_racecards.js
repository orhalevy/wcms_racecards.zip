/* results_general */
/*
 Dependencies - slick.js, jquery-ui (datepicker only)
 */

var results_general = (function (WidgetModule) {
    var init = function () {
        var $new_widget = $('.results_general');
        if (WidgetModule.checkIfExists($new_widget[0])){
            for (var i=0; i<$new_widget.length; i++){
                //$this is the current widget
                var $this = $($new_widget[i]);
                if(WidgetModule.checkInit($this)){
                    $.ajax({
                        url: document.location.origin + "/wp-content/plugins/wcms_frontend/wcms_ajax_handler.php?action=fetch_no_results_dates",
                        success: function(data) {
                            var blockedDates = data.endsWith("-1") ? JSON.parse(data.replace("]-1","]")) : JSON.parse(data);
                            $this['context']['blockedDates'] = blockedDates;
                        },
                        error: function(error) {
                            console.error('error', error);
                        }
                    });
                    _initSlicks($this);
                    _initDatepicker($this);
                    WidgetModule.updateInit($this);
                }
            }
        }
    };

    var _initSlicks = function($this) {
        var $navSlider = $this.find('.resultsNavBar');
        var _navSliderWidth = $navSlider.outerWidth();
        var $resultsNavTabs = $navSlider.find('.navTab');
        var $resultsGeneralTable = $this.find('.resultsGeneralTableContent');
        var _numberOfTabsToShow = $resultsNavTabs.length;
        var _totalNavWidth = 0;

        $( $resultsNavTabs ).each(function( index ) {
            _totalNavWidth += $( this ).outerWidth();
            if(_totalNavWidth > _navSliderWidth) {
                _numberOfTabsToShow = index + 0.5;
                return false;
            }
        });

        $navSlider.slick({
            dots: false,
            infinite: false,
            arrows: false,
            speed: 100,
            slidesToShow: _numberOfTabsToShow,
            slidesToScroll: 1,
            mobileFirst: true,
            variableWidth: true,
            focusOnSelect: true,
            swipe: true,
            asNavFor: $resultsGeneralTable
        });

        $resultsGeneralTable.slick ({
            dots: false,
            infinite: false,
            arrows: false,
            speed: 100,
            slidesToShow: 1,
            slidesToScroll: 1,
            focusOnSelect: true,
            swipe: true,
            asNavFor: $navSlider
        });

        /* add 0.25% to the left of the slide so the prev slide can be seen */
        $navSlider.on('afterChange', function(){
            var $currentSelectedSlide = $navSlider.find('.navTab.slick-slide.slick-current');
            var $navSlickTrack = $navSlider.find('.slick-track');
            if($currentSelectedSlide.attr('data-slick-index')!= 0) {
                $navSlickTrack.css('margin-left',$currentSelectedSlide.outerWidth()*0.25);
            }else {
                $navSlickTrack.css('margin-left',0);
            }
        });

        /* fix for a bug in the slick - doesn't change the tab slick-current after sliding the table content slick in desktop */
        $resultsGeneralTable.on('afterChange', function(){
            var $navTabSliders = $navSlider.find('.navTab.slick-slide');
            var inFocus = $resultsGeneralTable.find('.resultsTable.slick-slide.slick-current').data('slick-index');
            $navTabSliders.removeClass('slick-current');
            $navSlider.find('[data-slick-index="' + inFocus + '"]').addClass('slick-current');
        });
    };

    var _initDatepicker = function($this) {
        var $datepicker = $this.find('#datepicker');
        /* TODO: add location  */
        $datepicker.datepicker({
            showOn: "both",
            dateFormat: "dd/mm/yy",
            maxDate: "+0d",
            minDate: "-1y",
            beforeShowDay: blockDates,
            buttonImageOnly: true,
            onSelect: function(value) {
                var absoluteLink = $this.find('[data-absolute-link]').data('absolute-link');
                var currentDate = value.replace(/[/]/g, '-');
                window.location = '/' + absoluteLink + '/' + currentDate;
            }
        });

        var $datepickerIcon = $datepicker.parent().find('.ui-datepicker-trigger');
        $datepickerIcon.attr('alt',''); //hide all element connecred to the jQuery ui icons
        $datepicker.parent().append('<i class="far fa-calendar-alt calendarIcon color-base"></i>'); // add font awesome icons
        $datepicker.parent().find('.calendarIcon').on("click",function(){ //connect jQuery ui to the new icons
        var $datepickerDiv = $('#ui-datepicker-div');
            if($datepickerDiv.css('display') === 'none') {
                $datepickerIcon.trigger( "click" );
            } else {
                $datepickerDiv.css('display', 'none')
            }

        });

        function blockDates(dateObj) {
            var date = dateObj.toISOString().split('T')[0];
            var permitted_dates = $this['context']['blockedDates'];
            var d = new Date();
            return [permitted_dates.includes(date) || date === (new Date(d.setDate(d.getDate()-1))).toISOString().split('T')[0]];
        }
    };

    return{
        init:init
    }
})(WidgetModule);

/* results race page */
/*
    resultsRaceData - when user picks other venue the page stays the same and the data updates with ajax
    resultsRaceWidget- race cards widget functionality with show/hide details
 */

// updates all data in the page with ajax
var resultsRaceData = (function (WidgetModule) {
    var init = function () {
        var $raceWidget = $('.result-page-widget');
        if ($raceWidget[0]){
           var buttons   = $raceWidget.find('.listOfRaces .btn');
           var venueName = $raceWidget.find('.venueDataWrapper .name').html();
           var venueDate = $raceWidget.find('.venueDataWrapper .date').attr('data-for-url');
           var time      = $raceWidget.find('.btn.active>div').html();
           _updateUrl(venueDate,venueName, time);
           buttons.each(function () {
                $(this).click(function () {
                    if(!$(this).hasClass('active')){
                        $('.horseTable').hide('slow');
                        $('.horseLoader').html('🐎').show('slow');
                        $raceWidget.find('.listOfRaces .btn.active').removeClass('active').removeAttr('data-active');
                        $(this).addClass('active');
                        $(this).attr('data-active',true);
                        var venueTime =  $(this).text().trim();
                        var root = $(this).attr('data-url-root');
                        if(window)
                        $.ajax({
                            url: root + "/wp-content/plugins/wcms_frontend/wcms_ajax_handler.php?action=fetch_race_results&time=" + venueTime + "&date=" + venueDate + "&course=" + venueName,
                            dataType: "html",
                            complete: function(){
                               $('.horseLoader').hide('slow');
                               $('.horseTable').show('slow');
                            },
                            success: function(data) {
                                console.log(data);
                                _renderPage(data , $raceWidget);
                                _updateUrl(venueDate,venueName, venueTime , data);
                            },
                            error: function(error) {
                                console.error('error', error);
                            }
                        });
                    }
                })
           });
        }
    };

    function _renderPage(data, $raceWidget) {
        $raceWidget.attr('data-updated',true);
        var $data = data.substring(0, data.indexOf('</section>'));
        $('.automaticPageResults').replaceWith($data);
        var $title= $(".result-page-widget .venueData .listOfRaces li[data-active]").attr('data-race-title');
        $raceWidget.find('.title').html($title);
        $('#breadcrumbs').find('li:last-child span').html($title);
        race_cards_brand_and_cta.init();
        resultsRaceWidget.init();
    }
    var _updateStorage= function($title, $data , $fullUrl) {
        try {
            localStorage.setItem($title, $data);
            localStorage.setItem($fullUrl, $title);
        } catch(e) {
            console.log('error',e);
            localStorage.clear();
            localStorage.setItem($title, $data);
            localStorage.setItem($fullUrl, $title);
        }
    };

    var _renderPageFromStorage = function () {
        var $raceWidget  = $('.result-page-widget');
        var link = window.location.href;
        var n = link.lastIndexOf('/');
        var linkName = link.substring(n + 1);
        var title = localStorage.getItem(linkName);
        var data  = localStorage.getItem(title);
        $raceWidget.find('.listOfRaces .btn.active').removeClass('active').removeAttr('data-active');
        $raceWidget.find('.listOfRaces .btn').each(function () {
            var dataTitle = $(this).attr('data-race-title').replace(/ /g, "-").toLocaleLowerCase();
            if(dataTitle == title){
                $(this).addClass('active');
                $(this).attr('data-active',true);
                $('.listOfRaces').mCustomScrollbar("scrollTo",$(this));
            }
        });
        _renderPage(data, $raceWidget);

    };

    var _updateUrl = function($date , $name , $time, $data) {
        $date = $date.replace(/\./g, '-' );
        $time = $time.replace(/:/g,'');
        $name = $name.replace(/ /g, '_').toLocaleLowerCase();
        if(!($resultsBaseLink = $(".result-page-widget .venueData ul.listOfRaces").attr('data-results-base-link'))){
            $resultsBaseLink = "";
        }else{
            $resultsBaseLink =  '/' + $resultsBaseLink;
        }

        var $title;
        if($('.btn.active').attr('data-active') !== undefined){
             $title = $(".result-page-widget .venueData .listOfRaces li[data-active]").attr('data-race-title').replace(/ /g, "-").toLocaleLowerCase();
        }else{
             $title = $('.result-page-widget .venueData .listOfRaces li.btn.active').attr('data-race-title').replace(/ /g, "-").toLocaleLowerCase();
        }


        var $fullUrl = $name+'-'+$time+'-'+$title;

        if($('.result-page-widget').attr('data-updated')){
            // if back ntn will take to another race
            history.pushState(null, null, $resultsBaseLink + '/'+$date+ '/'+$name+'-'+$time+'-'+$title);
            _updateStorage($title, $data , $fullUrl);
        }else{
            // if back ntn will take to general results page
            history.replaceState(null, null, $resultsBaseLink + '/'+$date+ '/'+$name+'-'+$time+'-'+$title);
            $data= $('.horseTable').html();
            _updateStorage($title, $data , $fullUrl);
        }
        document.title = "Results: "+$('.result-page-widget .venueData .listOfRaces li.btn.active').attr('data-race-title');

        window.onpopstate = function (e) {
            e.preventDefault();
            _renderPageFromStorage()
        }
    };

    return{
        init:init
    }
})(WidgetModule);

// race_cards_widget - automaticPage layout
var resultsRaceWidget = (function (WidgetModule) {
    var init = function () {
        var $raceCards = $('.automaticPageResults');
        if (WidgetModule.checkIfExists($raceCards[0])) {
            $raceCards.find('.horsesList li').each(function(){
                $(this).on('click.collapse',function(){
                    if(!$(this).hasClass('noData')){
                        $(this).toggleClass('in');
                        $(this).find('.resultsDetails').collapse('toggle');
                    }
                })
            });

            enquire.register(queryMobile, {
                match: function () {
                    $raceCards.find('.horsesList li').each(function () {
                        var $resultsDetails = $(this).find('.resultsDetails');
                        $resultsDetails.appendTo($(this).find('.horseDetails2'));
                        $(this).off('click.collapse');
                        $(this).find('.horseDetails1').on('click.mobile_collapse',function(){
                            $(this).parent().toggleClass('in');
                            $(this).siblings('.horseDetails2').collapse('toggle');
                        })
                    });
                },
                unmatch: function() {
                    $raceCards.find('.horsesList li').each(function () {
                        $(this).find('.horseDetails1').off('click.mobile_collapse');
                        var $resultsDetails = $(this).find('.resultsDetails');
                        $resultsDetails.insertAfter($(this).find('.angle'));
                        $(this).on('click.collapse',function(){
                            $(this).toggleClass('in');
                            $(this).find('.resultsDetails').collapse('toggle');
                        })
                    });
                }

            })
        }
    };
    return{
        init:init
    }
})(WidgetModule);

// adds scroll to hardcoded elements in race+result race pages ( race times navigation )
var raceCard = (function (WidgetModule) {
    var init = function () {
        var $raceCard = $('.listOfRaces');
        if ($raceCard[0]){
                $raceCard.mCustomScrollbar({
                    axis:"x",
                    theme:"dark-3",
                    advanced:{
                        autoExpandHorizontalScroll:true
                    }
                });
                $raceCard.mCustomScrollbar("scrollTo","li.btn.active");
        }
    };
    return{
        init:init
    }
})(WidgetModule);

/*###################################### document ready event ######################################*/
$(document).ready(function() {
    results_general.init();
    resultsRaceData.init();
    resultsRaceWidget.init();
    raceCard.init();
});