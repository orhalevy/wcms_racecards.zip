<?php
/*
    Plugin Name: WCMS Racecards
    Version: 1.134
    Description: Horse Racing
*/

define('WP_CONTENT_PATH', WP_CONTENT_DIR.'/');
define('RACECARDS_PLUGIN_PATH', WP_CONTENT_PATH . 'plugins/wcms_racecards/');
define('LOCAL_TWIG_PATH',  WP_CONTENT_PATH.'themes/'. wp_get_theme().'/views/');
define('PLUGIN_TWIG_PATH', RACECARDS_PLUGIN_PATH.'views/');

require_once 'custom-post-types.php';
require_once 'services/pa-service.php';
require_once 'plugin_settings/settings-page-template.php';
require_once 'services/WCMSRacecardsUtils.php';
require_once 'plugin_settings/settings-page-api.php';
require_once 'services/url_handler.php';

/* Enqueue JS scripts */
if(!is_admin()){
    wp_enqueue_script( 'mCustomScrollbar', plugins_url( 'wcms_widgets/js/jquery.mCustomScrollbar.concat.min.js'), array('jquery'), '', true);
    wp_enqueue_script( 'racecards_front_scripts', plugins_url( 'wcms_racecards/js/wcms_racecards.js'), array('jquery','widgets_scripts'), '', true);
}

/* Enqueue CSS styles */
wp_enqueue_style( 'slick',               plugins_url( 'wcms_widgets/css/dep/slick/slick.css' ));
wp_enqueue_style( 'mCustomScrollbar',    plugins_url( 'wcms_widgets/css/dep/jquery.mCustomScrollbar.min.css' ) );

/* Get Timber to recognize the views folder */
Timber::$locations = ABSPATH . 'wp-content/plugins/wcms_racecards/views';

/* get specific race's results for ajax call from detailed results page */
add_action( 'MY_AJAX_HANDLER_fetch_race_results', 'wcms_racecards_fetch_race_results');
function wcms_racecards_fetch_race_results(){
    echo WCMSRacecardsUtils::fetch_race_results();
}

add_action( 'MY_AJAX_HANDLER_fetch_no_results_dates', 'wcms_racecards_fetch_no_results_dates');
function wcms_racecards_fetch_no_results_dates(){
    echo WCMSRacecardsUtils::fetch_no_results_dates();
}

/* Wrapping the url_handler with WPML load hook gives us the ability to translate url params */
add_action( 'wpml_loaded', 'run_url_handling');
$racecards_url_handler = new racecards_url_handler();
function run_url_handling() {

    // Exit early in case we are running inside WP CLI.
    // The global $racecards_url_handler is not available globally on WP CLI.
    // @see https://jira-webpals.com:8443/browse/PNP-348 comments for more info. 
    if ( defined( 'WP_CLI' ) && WP_CLI ) {
        return;
    }

    global $racecards_url_handler;
    $racecards_url_handler->set_translations();
    $racecards_url_handler->set_all_racecards_posts_and_pages_permalinks_with_base_slug();
    add_action('parse_request', array($racecards_url_handler, 'parse_url'));
}

function set_results_race_title_tag($title) {
    global $post;

    $race_data = WCMSRacecardsUtils::get_race_by_id($_REQUEST['race_id'])->data[0];
    $page_template = get_post_meta($post->ID, '_wp_page_template', true);
    if( $page_template == 'results-race.php' ) {
        $title = __('Results', 'wcms_racecards').": ".$race_data->title;
    }
    return $title;
}
add_filter('wpseo_title', 'set_results_race_title_tag');

/* When plugin is activated, generate the relevant page/post types */
function generate_parent_files() {
    require_once 'dynamic_generator/parent-files-generator.php';
}
register_activation_hook(__FILE__, 'generate_parent_files');

/* When plugin is deactivated, we remove the no longer needed page/post types. The goal is to clean the site from plugin's traces */
function remove_parent_files() {
    require_once 'dynamic_generator/parent-files-remover.php';
}
register_deactivation_hook(__FILE__, 'remove_parent_files');

/* Racecards Menu */
function racecards_service_menu() {
    add_menu_page('Horse Racing Racecards - Settings', 'Racecards Client Settings', 'manage_options', 'racecards_client', 'racecards_settings_page');
    add_submenu_page('racecards_client' , 'Today Page',  'Today Page', 'manage_options', 'today_page_menu' , 'today_settings_page' );
    add_submenu_page('racecards_client' , 'Tomorrow Page',  'Tomorrow Page', 'manage_options', 'tomorrow_page_menu' , 'tomorrow_settings_page' );
    add_submenu_page('racecards_client' , 'Race Pages',  'Race Pages', 'manage_options', 'race_page_menu' , 'race_pages_menu' );
    add_submenu_page('racecards_client' , 'Results General Page',  'Results General Page', 'manage_options', 'results_general_menu' , 'results_general_settings_page' );
    add_submenu_page('racecards_client' , 'Results Race Page',  'Results Race Page', 'manage_options', 'results_race_menu' , 'results_race_settings_page' );
}
add_action('admin_menu', 'racecards_service_menu');

/* Menu navigation handlers */
function today_settings_page() {
    WCMSRacecardsUtils::get_page_management_menu('today-page.php');
}
function tomorrow_settings_page() {
    WCMSRacecardsUtils::get_page_management_menu('tomorrow-page.php');
}
function race_pages_menu() {
    WCMSRacecardsUtils::get_post_management_menu('horse-race-card');
}
function results_general_settings_page() {
    WCMSRacecardsUtils::get_page_management_menu('results-general.php');
}
function results_race_settings_page() {
    WCMSRacecardsUtils::get_page_management_menu('results-race.php');
}

/* This hook helps us to stop before publishing a post and block an invalid action of posting */
add_action('transition_post_status', 'send_new_post', 10, 3);

function send_new_post($new_status, $old_status, $post) {
    WCMSRacecardsUtils::singleton_admin_logic($new_status, $old_status, $post);
}

/* Initialize and load the settings page */
function racecards_settings_page() {
    register_racecards_plugin_settings();
?>
    <div class="wrap">
        <h2><?php print $GLOBALS['title']; ?></h2>
        <p>Racecards plugin global settings. The settings you set here effect the whole plugin.</p>
        <form method="post" action="#">
            <?php
                settings_fields( 'racecards_plugin_settings_group' );
                do_settings_sections( 'racecards_client' );
                print_placeholders_manual();
                submit_button();
            ?>
        </form>
    </div>
    <?
}

/* Creating settings fields */
function register_racecards_plugin_settings() {
    settings_page_template('racecards_plugin_settings_group');
}